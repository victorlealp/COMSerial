#include "COMSerial.h"
#include <Servo.h>

Servo servo[5];

//------------------------Funções de Instância------------------------//
COMSerial::COMSerial(bool displayMsg){
  _msg = displayMsg;
}

void COMSerial::begin(int baudRate){
  Serial.begin(baudRate);
  if(_msg)
    Serial.println("Biblioteca instanciada com sucesso!");
}

void COMSerial::servos(short int A, short int B, short int C, short int D, short int E){
  int aux = 0;

  //Contagem de variáveis válidas
  if(A != 0)
    aux++;
  if(B != 0)
    aux++;
  if(C != 0)
    aux++;
  if(D != 0)
    aux++;
  if(E != 0)
    aux++;

  //Instanciação
  switch(aux){
    case 5: servo[4].attach(E);
    case 4: servo[3].attach(D);
    case 3: servo[2].attach(C);
    case 2: servo[1].attach(B);
    case 1: servo[0].attach(A);
      if(_msg){
        Serial.print(aux);
        Serial.println(" servo(s) acoplados(s)!");
      }
      break;
    default:
    if(_msg)
      Serial.println("Nenhum servo acoplado!");
  }
}

void COMSerial::portas_O(short int A, short int B, short int C, short int D, short int E, short int F, short int G,
                                      short int H, short int I, short int J, short int K, short int L){
  short int aux = 0;
  
  //Contagem de variáveis válidas
  if(A!=0)
    aux++;
  if(B!=0)
    aux++;
  if(C!=0)
    aux++;
  if(D!=0)
    aux++;
  if(E!=0)
    aux++;
  if(F!=0)
    aux++;
  if(G!=0)
    aux++;
  if(H!=0)
    aux++;
  if(I!=0)
    aux++;
  if(J!=0)
    aux++;
  if(K!=0)
    aux++;
  if(L!=0)
    aux++;

  //Instanciação
  switch(aux){
    case 12:  pinMode(L, OUTPUT);
    case 11:  pinMode(K, OUTPUT);
    case 10:  pinMode(J, OUTPUT);
    case 9:  pinMode(I, OUTPUT);
    case 8:  pinMode(H, OUTPUT);
    case 7:  pinMode(G, OUTPUT);
    case 6:  pinMode(F, OUTPUT);
    case 5:  pinMode(E, OUTPUT);
    case 4:  pinMode(D, OUTPUT);
    case 3:  pinMode(C, OUTPUT);
    case 2:  pinMode(B, OUTPUT);
    case 1:  pinMode(A, OUTPUT);
      if(_msg){
        Serial.print(aux);
        Serial.println(" porta(s) OUTPUT definida(s)!");
      }
      break;
    default:
    if(_msg)
      Serial.println("Nenhuma porta OUTPUT definida!");
    
  } 
}

void COMSerial::portas_I(short int A, short int B, short int C, short int D, short int E, short int F, short int G,
                                      short int H, short int I, short int J, short int K, short int L){
  short int aux = 0;
  
  //Contagem de variáveis válidas
  if(A!=0)
    aux++;
  if(B!=0)
    aux++;
  if(C!=0)
    aux++;
  if(D!=0)
    aux++;
  if(E!=0)
    aux++;
  if(F!=0)
    aux++;
  if(G!=0)
    aux++;
  if(H!=0)
    aux++;
  if(I!=0)
    aux++;
  if(J!=0)
    aux++;
  if(K!=0)
    aux++;
  if(L!=0)
    aux++;

  //Instanciação
  switch(aux){
    case 12:  pinMode(L, INPUT);
    case 11:  pinMode(K, INPUT);
    case 10:  pinMode(J, INPUT);
    case 9:  pinMode(I, INPUT);
    case 8:  pinMode(H, INPUT);
    case 7:  pinMode(G, INPUT);
    case 6:  pinMode(F, INPUT);
    case 5:  pinMode(E, INPUT);
    case 4:  pinMode(D, INPUT);
    case 3:  pinMode(C, INPUT);
    case 2:  pinMode(B, INPUT);
    case 1:  pinMode(A, INPUT);
      if(_msg){
        Serial.print(aux);
        Serial.println(" porta(s) INPUT definida(s)!");
      }
      break;
    default:
    if(_msg)
      Serial.println("Nenhuma porta INPUT definida!");
    
  } 
}

//------------------------Funções de Controle-------------------------//

void COMSerial::executar(char prefixo, short int cmd){

  //Print Comando
  Serial.print(prefixo); Serial.print(" "); Serial.println(cmd);

  //Ligar e Desligar Portas
  if(prefixo == 'p')
    digitalWrite(cmd, !digitalRead(cmd));

  //Comandar Servo 1
  if(prefixo == 'a')
    servo[0].write(cmd);

  //Comandar Servo 2
  if(prefixo == 'b')
    servo[1].write(cmd);

  //Comandar Servo 3
  if(prefixo == 'c')
    servo[2].write(cmd);

  //Comandar Servo 4
  if(prefixo == 'd')
    servo[3].write(cmd);

  //Comandar Servo 5
  if(prefixo == 'e')
    servo[4].write(cmd);
}

void COMSerial::concatenar(String comando){
  char cmd[3] = {};
  
  for(int i = 0; i<3; i++)
    cmd[i] = comando[i+1];
    
  Serial.println(comando);
  
  executar(comando[0], atoi(cmd));
}

#ifndef tl
#define tl

#if (ARDUINO >= 100)
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

class COMSerial{
  public:
    //Construtor
    COMSerial(bool displayMsg=false);

    //Métodos
    void begin(int baudRate=9600);
    void servos(short int A=0, short int B=0, short int C=0, short int D=0, short int E=0);
    void portas_O(short int A=0, short int B=0, short int C=0, short int D=0, short int E=0, short int F=0, short int G=0,
                                                short int H=0, short int I=0, short int J=0, short int K=0, short int L=0);
    void portas_I(short int A=0, short int B=0, short int C=0, short int D=0, short int E=0, short int F=0, short int G=0,
                                                short int H=0, short int I=0, short int J=0, short int K=0, short int L=0);
    void concatenar(String comando);
    void executar(char prefixo, short int cmd);

    private:
    bool _msg;
      
};
#endif
